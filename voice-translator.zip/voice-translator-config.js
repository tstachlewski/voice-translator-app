var bucketName = 'REPLACE WITH VALUE of VoiceTranslatorBucket KEY';
var IdentityPoolId = 'REPLACE WITH VALUE of IdentityPoolIdOutput KEY';
var lambdaFunction = 'REPLACE WITH VALUE of VoiceTranslatorLambda KEY';
